from django.shortcuts import render
from .models import users
from covchain_backend.response import Response
import json
from passlib.hash import sha256_crypt
# Create your views here.

def signin(request):
    if request.method == "POST":
        json_data = json.loads(request.body)
        
        #serealize json
      
        email = json_data["email"]
        password = json_data["password"]
       
        #CHECKING USER
        user = users.objects.filter(email=email).first()
        if not user:
            return Response.badRequest(message='FAILED SIGNIN!')



        if sha256_crypt.verify(password, user.password):
            return Response.ok(message="Berhasil masuk!")
        else:
            return Response.badRequest(message="FAILED SIGNIN!")  


def signup(request):
    if request.method == "POST":

        json_data = json.loads(request.body)

        #SEREALIZE
        name = json_data['name']
        instansi = json_data['instansi']
        role = json_data['role']
        email = json_data['email']
        password = json_data['password']

        user = users.objects.filter(email=email).first()
        if user:
            return Response.badRequest(message='Pengguna telah digunakan!')

        #generatepassword&Save
        password = sha256_crypt.encrypt(password)
        user = users(name = name,email = email, password = password, instansi = instansi, role = "role")
        user.save()


        return Response.ok(values='created', message="UP UP UP")