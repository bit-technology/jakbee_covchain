from . import views
from django.urls import path

urlpatterns = [
    path('', views.contract, name='contract'),
    path('<str:id>/', views.contract, name='verify'),
    path('history/<str:user_id>/', views.history, name='contract'),
]
