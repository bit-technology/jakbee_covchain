from django.shortcuts import render
from covchain_backend.response import Response
import json
import os

# Create your views here.

def contract(request,id = None):




    if request.method == "POST":
        json_data = json.loads(request.body)
        
        #serealize json
      
        chain_id = json_data["chain_id"]
        user_id = json_data["user_id"]
        name = json_data["name"]
        roles = json_data["roles"]
        date = json_data["date"]
        action = json_data["action"]
        location = json_data["location"]
        temp = json_data["temp"]
        instance = json_data["instance"]
        description = json_data["description"]
        
        data = '{},"{}","{}","{}","{}","{}","{}","{}","{}","{}",'.format(chain_id,user_id,str(name),str(roles),str(date),str(action),str(location),str(temp),str(instance),str(description))
        print(data)
        
        openWallet = "contract/VEXANIUM/./cleos open wallet"
        unlockWallet = "contract/VEXANIUM/./cleos wallet unlock --password PW5KCvAEv8oSueexpJMKpDUvjav6xEVxcxi5ercvCH2QC9U9uSxhn"
        cmd = "contract/VEXANIUM/./cleos --url https://explorer.vexanium.com:6960 push action sertifigo123 make '["+ data +"]' -p sertifigo123@active -j"
        
        try :
            os.popen(openWallet)
            os.popen(unlockWallet)
        except:
            pass

        stream = os.popen(cmd)
        output = stream.read()

        txData = json.loads(output)
        print(txData["processed"]["action_traces"][0]["act"]["data"]) 
        #make your contract
        return Response.ok(values=txData["processed"]["action_traces"][0]["act"]["data"], message="POST")

    
    if request.method == "GET":

        #make your contract


        openWallet = "contract/VEXANIUM/./cleos open wallet"
        unlockWallet = "contract/VEXANIUM/./cleos wallet unlock --password PW5KCvAEv8oSueexpJMKpDUvjav6xEVxcxi5ercvCH2QC9U9uSxhn"
        cmd = "contract/VEXANIUM/./cleos --url https://explorer.vexanium.com:6960 push action sertifigo123 getchain '["+ id +"]' -p sertifigo123@active -j"
        
        try :
            os.popen(openWallet)
            os.popen(unlockWallet)
        except:
            pass

        stream = os.popen(cmd)
        output = stream.read()

        txData = json.loads(output)
        chainData = txData["processed"]["action_traces"][0]["console"]
        arrData = str(chainData).split("**")
        
        # print(arrChain) 

        # JSON data: 
        key = 0
        val = arrData[0]
        x =  {key:val}
        
        a = len(arrData) - 1
        print(a)
        for k in range(1,a):
            y = {k:arrData[k]} 
            x.update(y)


        return Response.ok(values=x, message="GET")

        

def history(request,user_id = None):
    if request.method == "GET":

        #make your contract


        openWallet = "contract/VEXANIUM/./cleos open wallet"
        unlockWallet = "contract/VEXANIUM/./cleos wallet unlock --password PW5KCvAEv8oSueexpJMKpDUvjav6xEVxcxi5ercvCH2QC9U9uSxhn"
        cmd = "contract/VEXANIUM/./cleos --url https://explorer.vexanium.com:6960 push action sertifigo123 gethistory '["+ user_id +"]' -p sertifigo123@active -j"
        
        try :
            os.popen(openWallet)
            os.popen(unlockWallet)
        except:
            pass

        stream = os.popen(cmd)
        output = stream.read()

        txData = json.loads(output)
        chainData = txData["processed"]["action_traces"][0]["console"]
        arrData = str(chainData).split("**")
        
        # print(arrChain) 

   
        # JSON data: 
        key = 0
        val = arrData[0]
        x =  {key:val}
        
        a = len(arrData) - 1
        print(a)
        for k in range(1,a):
            y = {k:arrData[k]} 
            x.update(y) 

        return Response.ok(values=x, message="GET")    